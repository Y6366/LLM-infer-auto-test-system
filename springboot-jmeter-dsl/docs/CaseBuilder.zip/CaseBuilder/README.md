# CaseBuilder

**基于多Agent协作的测试用例自动生成系统**

## 架构总览

```
┌──────────────────────────────────────────────────────────────┐
│                     用户输入层                                │
│            (自然语言测试场景描述)                               │
└──────────────────────┬───────────────────────────────────────┘
                       │
                       ▼
┌──────────────────────────────────────────────────────────────┐
│                  Orchestrator 编排器                          │
│        (流程控制、检查点、日志、中间产物管理)                     │
└──────┬──────────┬──────────┬──────────┬─────────────────────┘
       │          │          │          │
       ▼          ▼          ▼          ▼
┌──────────┐ ┌──────────┐ ┌──────────┐ ┌──────────┐
│ Intent   │ │ Retrieval │ │ CodeGen  │ │ Review   │
│ Agent    │ │ Agent     │ │ Agent    │ │ Agent    │
│          │ │           │ │          │ │          │
│ 意图识别  │ │ 知识检索   │ │ 代码生成  │ │ 质量校验  │
│ 标签提取  │ │ 方法匹配   │ │ 模板填充  │ │ AST检查   │
│ 模式匹配  │ │ 调用链查询 │ │ 代码组装  │ │ 规范检查  │
└──────────┘ └──────────┘ └──────────┘ └──────────┘
       │          │          │          │
       ▼          ▼          ▼          ▼
┌──────────────────────────────────────────────────────────────┐
│                    知识层                                     │
│  ┌────────────┐ ┌────────────┐ ┌────────────┐               │
│  │ 方法词典    │ │ 场景模式库  │ │ 代码模板库  │               │
│  │ glossary   │ │ patterns   │ │ templates  │               │
│  └────────────┘ └────────────┘ └────────────┘               │
│  ┌────────────┐ ┌────────────┐ ┌────────────┐               │
│  │ V1骨架/签名│ │ V2依赖/链路│ │ V3工具规范  │               │
│  └────────────┘ └────────────┘ └────────────┘               │
└──────────────────────────────────────────────────────────────┘
                       │
                       ▼
┌──────────────────────────────────────────────────────────────┐
│                  工具层                                       │
│  build_context.py - 多层上下文构建工具                         │
│  (RecursiveRetriever AST解析器)                               │
└──────────────────────────────────────────────────────────────┘
```

## 快速开始

### 1. 配置环境
```bash
# Python 3.9+ 即可，无需额外依赖
cd CaseBuilder
python3 --version
```

### 2. 运行Demo
```bash
# 交互式Demo
python3 demo/run_demo.py

# 或命令行直接运行
python3 workflow/orchestrator.py "deepseek r1 671b，vllm推理，bf16权重，32p，CEVAL一致性测试"
```

### 3. 查看输出
```bash
# 生成的用例
ls output/

# 中间产物
ls output/.artifacts_*/
```

## 目录结构

```
CaseBuilder/
├── README.md                    # 本文件
├── config/
│   └── settings.yaml            # 全局配置
├── knowledge/                   # 知识库
│   ├── method_glossary.json     # 公共方法词典
│   ├── rules/
│   │   ├── coding_rules.md      # 编码规范
│   │   └── scene_patterns.md    # 场景模式库
│   └── templates/
│       ├── vllm_perf_acc_template.py  # 性能+精度模板
│       └── vllm_det_template.py       # 一致性测试模板
├── agents/                      # Agent集合
│   ├── __init__.py
│   ├── intent_agent.py          # 意图识别Agent
│   ├── retrieval_agent.py       # 知识检索Agent
│   ├── codegen_agent.py         # 代码生成Agent
│   └── review_agent.py          # 质量校验Agent
├── workflow/
│   ├── __init__.py
│   └── orchestrator.py          # 工作流编排器
├── tools/
│   ├── __init__.py
│   └── build_context.py         # 上下文构建工具
├── demo/
│   └── run_demo.py              # 快速演示
├── docs/
│   ├── OPERATION_MANUAL.md      # 操作手册
│   ├── DEBUG_GUIDE.md           # 调试指南
│   └── ARCHITECTURE.md          # 架构文档
├── context_output/              # 上下文视图（由工具生成）
├── output/                      # 生成的用例输出
└── logs/                        # 运行日志
```

## 文档

- 📖 [详细操作手册](docs/OPERATION_MANUAL.md)
- 🐛 [调试指南](docs/DEBUG_GUIDE.md)
- 🏗️ [架构文档](docs/ARCHITECTURE.md)
